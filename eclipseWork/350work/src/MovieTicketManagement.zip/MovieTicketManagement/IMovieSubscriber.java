package MovieTicketManagement;

public interface IMovieSubscriber {
	void update();
}
